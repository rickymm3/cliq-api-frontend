import { Controller } from "@hotwired/stimulus"

// This controller is currently unused as we moved to a pure CSS sticky header approach
// keeping file structure for potential future enhancements
export default class extends Controller {
  connect() {
    // No-op
  }
}
;
