import "@hotwired/turbo-rails"
import "controllers"

import "trix"
import "@rails/actiontext"

console.log("Application JS Loaded");
